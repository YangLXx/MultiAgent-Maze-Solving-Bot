# How to use
Run "python Learner.py" for single agent maze solver
Run "python multiagent.py" for multi-agent maze solver

# Reinforcement_Learning
maze solving bot using Qlearning . Compairing single vs multi agent system.

Reinforcement learning is an area of machine  learning inspired by behaviorist psychology. It allows machines and software agents to automatically determine the ideal behavior within a specific context, in order to maximize its performance.

## Compute the shortest path in a Dynamic Maze using both single and multi agent reinforcement learning.

## ![](/imgs/1.jpg) 
## ![](/imgs/2.jpg) 
## ![](/imgs/3.jpg) 
## ![](/imgs/4.jpg) 
## ![](/imgs/5.jpg) 
## ![](/imgs/6.jpg) 
## ![](/imgs/7.jpg) 
